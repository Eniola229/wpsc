<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="author" content="Untree.co">
    <link rel="shortcut icon" href="https://res.cloudinary.com/dtxifnjiy/image/upload/v1736464781/WhatsApp_Image_2025-01-09_at_3.59.48_PM_kuxprl.jpg">

    <meta name="description" content="" />
    <meta name="keywords" content="bootstrap, bootstrap5" />
    

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600&family=Inter&display=swap" rel="stylesheet">


    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/tiny-slider.css">
    <link rel="stylesheet" href="css/glightbox.min.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/style.css">

    <title>Way of Peace Salvation Centre Worldwide. </title>
</head>
<style type="text/css">
    .image-container {
    width: 100%; /* Matches the column width */
    aspect-ratio: 1/1; /* Ensures images are square */
    overflow: hidden; /* Hides overflowing parts of the image */
    position: relative;
}

.image-container img {
    width: 100%;
    height: 100%;
    object-fit: cover; /* Ensures the image fills the container while maintaining proportions */
}

</style>
<body >

    <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
            <div class="site-mobile-menu-close">
                <span class="icofont-close js-menu-toggle"></span>
            </div>
        </div>
        <div class="site-mobile-menu-body"></div>
    </div>

    <nav class="site-nav">
        <div class="container">
            <div class="site-navigation">
                <a href="{{ url('/') }}" class="logo m-0 float-left"><img src="https://res.cloudinary.com/dtxifnjiy/image/upload/v1736464781/WhatsApp_Image_2025-01-09_at_3.59.48_PM_kuxprl.jpg" style="max-height: 80px; max-width: 100px; width: auto;" /></a>

                <ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu float-end">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li class="active"><a href="{{ url('sermons') }}">Sermons</a></li>
                    <li><a href="{{ url('ministry') }}">Ministries</a></li>
                    <li><a href="{{ url('events') }}">Events</a></li>
                    <li><a href="{{ url('/gallery') }}">Gallery</a></li>
                    <li><a href="{{ url('contact') }}">Contact</a></li>
                    <li class="cta-button"><a href="{{ url('EDBTI') }}">EDBTI</a></li>
                    <li class="cta-button"><a href="{{ url('give') }}">Giving</a></li>
                </ul>

                

                <a href="#" class="burger ms-auto float-end site-menu-toggle js-menu-toggle d-inline-block d-lg-none light" data-toggle="collapse" data-target="#main-navbar">
                    <span></span>
                </a>

                
            </div>
        </div>
    </nav>
	
	
	<div class="hero page-inner overlay" style="background-image: url('images/landscape-1.jpg'); ">

		<div class="container">
			<div class="row justify-content-center align-items-center">
				<div class="col-lg-9 text-center mt-5">

					<h1 class="heading" data-aos="fade-up">Misinterpreted verse John8 32</h1>
					<p class="text-white-50 mb-5" data-aos="fade-up" data-aos-delay="100">06 August 2024 • By Evangelist E.K Aransiola </p>
					<nav aria-label="breadcrumb" data-aos="fade-up" data-aos-delay="200">
						<ol class="breadcrumb text-center justify-content-center">
							<li class="breadcrumb-item "><a href="{{ url('/') }}">Home</a></li>
							<li class="breadcrumb-item "><a href="{{ url('sermons') }}">Sermons</a></li>
							<li class="breadcrumb-item active text-white-50" aria-current="page">Misinterpreted verse John8 32</li>
						</ol>
					</nav>

				</div>
			</div>


		</div>
	</div>


	

	<div class="section">
		<div class="container">
			<div class="row justify-content-center mb-5">
				<div class="col-lg-7" data-aos="fade-up">
					<iframe width="560" style="height: 300px;" height="300" src="https://www.youtube.com/embed/X9P4ceAn0dM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen class="img-fluid mb-3 rounded"></iframe>

				</div>
			</div>

			<div class="row justify-content-center">
				<div class="col-lg-7" data-aos="fade-up" data-aos-delay="100">
		<!-- 			<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>

					<p>A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>


					<p>Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.</p>

					
					<p>The Big Oxmox advised her not to do so, because there were thousands of bad Commas, wild Question Marks and devious Semikoli, but the Little Blind Text didn’t listen. She packed her seven versalia, put her initial into the belt and made herself on the way.</p>
					
					<p>When she reached the first hills of the Italic Mountains, she had a last view back on the skyline of her hometown Bookmarksgrove, the headline of Alphabet Village and the subline of her own road, the Line Lane. Pityful a rethoric question ran over her cheek, then she continued her way.</p>


					
					<p>On her way she met a copy. The copy warned the Little Blind Text, that where it came from it would have been rewritten a thousand times and everything that was left from its origin would be the word "and" and the Little Blind Text should turn around and return to its own, safe country. But nothing the copy said could convince her and so it didn’t take long until a few insidious Copy Writers ambushed her, made her drunk with Longe and Parole and dragged her into their agency, where they abused her for their.</p>
 -->
					
				</div>
			</div>
		</div>
	</div>

	

	<div class="section sec-cta bg-secondary">
		<div class="container">
			<div class="row align-items-center" data-aos="fade-up">
				<div class="col-lg-9 text-center text-md-start mb-4 mb-md-0">
					<h2 class="heading text-white">Support our mission by giving towards the spreading of our sermons.</h2>
				</div>		
				<div class="col-lg-3 text-center text-md-end" data-aos="fade-up" data-aos-delay="100">
					<a href="give.html" class="btn btn-primary py-3 px-5">Give Now</a>
				</div>

			</div>		
		</div>		
	</div>



    <div class="site-footer bg-white">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="widget">
                        <h3>Contact</h3>
                        <address>HOUSE 25 LASISI DAUDA STR IGANDO LAGOS NIGERIA</address>
                        <ul class="list-unstyled links">
                            <li><a href="tel://11234567890">+234 802 358 8202</a></li>
                            <li><a href="mailto:wayofpeacesalvationcentreworld@gmail.com">wayofpeacesalvationcentreworld@gmail.com</a></li>
                        </ul>
                    </div> <!-- /.widget -->
                </div> <!-- /.col-lg-4 -->
                <div class="col-lg-4">
                    <div class="widget">
                        <h3>Quick Links</h3>
                        <ul class="list-unstyled float-start links">
                            <li><a href="{{ url('sermons') }}">Sermons</a></li>
                            <li><a href="{{ url('ministry') }}">Ministries</a></li>
                            <li><a href="{{ url('events') }}">Events</a></li>
                            <li><a href="{{ url('/gallery') }}">Gallery</a></li>
                            <li><a href="{{ url('contact') }}">Contact</a></li>
                            <li><a href="{{ url('EDBTI') }}">EDBTI</a></li>
                            <li><a href="{{ url('give') }}">Giving</a></li>
                        </ul>
                        
                    </div> <!-- /.widget -->
                </div> <!-- /.col-lg-4 -->
                <div class="col-lg-4">
                    <div class="widget">
                        <h3>Links</h3>
                        <ul class="list-unstyled links">
                            <li><a href="{{ url('contact') }}">Contact us</a></li>
                            <li><a href="{{ url('give') }}">Giving</a></li>
                        </ul>

                        <ul class="list-unstyled social">
                            <li><a href="https://youtube.com/@evangelistkayodeemmanuel493?si=qusRkd_rmcKjbJ1k"><span class="icon-youtube"></span></a></li>
                            <li><a href="https://whatsapp.com/channel/0029VaxoYnf1NCrPmtzbyA0M"><span class="icon-whatsapp"></span></a></li>
                            <li><a href="https://whatsapp.com/channel/0029VaVRDIyI1rcfnjgY3R0E"><span class="icon-whatsapp"></span></a></li>
                            <li><a href="https://www.facebook.com/messageoflife60?mibextid=ZbWKwL"><span class="icon-facebook"></span></a></li>
                        </ul>
                    </div> <!-- /.widget -->
                </div> <!-- /.col-lg-4 -->
            </div> <!-- /.row -->

            <div class="row mt-5">
                <div class="col-12 text-center">
                    <p class="mb-0">Copyright &copy;<script>document.write(new Date().getFullYear());</script>. All Rights Reserved. &mdash; Designed by <a href="https://africicl.com.ng">AfricTech</a>
                    </p>
                </div>
            </div>
        </div> <!-- /.container -->
    </div> <!-- /.site-footer -->


	<!-- Preloader -->
	<div id="overlayer"></div>
	<div class="loader">
		<div class="spinner-border text-primary" role="status">
			<span class="visually-hidden">Loading...</span>
		</div>
	</div>




	<script src="js/bootstrap.bundle.min.js"></script>
	<script src="js/tiny-slider.js"></script>
	<script src="js/glightbox.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/navbar.js"></script>
	<script src="js/counter.js"></script>
	<script src="js/custom.js"></script>

	
</body>
</html>
